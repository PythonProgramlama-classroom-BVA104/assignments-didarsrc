import pandas as pd #veri analizi için kütüphane
import matplotlib.pyplot as plt #veri görselleştirme için kütüphane

class DataPreprocessor: #veri ön işleme sınıfı oluşturur

    def __init__(self, dosya_yolu): #nesne oluşturulunca ilk çalışan metot
        self.__veri = pd.read_csv(dosya_yolu) #CSV dosyasını okuyup private değişkene atıyoruz


    def veri_ozeti(self): #veri setinin genel özetini verir

        print(self.__veri.head()) #ilk 5 satırı gösterir
        print(self.__veri.info()) #sütun bilgisi ve veri tiplerini gösterir
        print(self.__veri.describe(include="all")) #sayısal istatistikleri ve kategorik özetleri gösterir


    def eksik_veri_kontrolu(self): #eksik veri kontrolü yapar

        print(self.__veri.isnull().sum()) #her sütundaki eksik veri sayısını gösterir


    def eksikleri_doldur(self, strateji="mean"): #eksik verileri doldurmak için strateji belirler

        sayisal = self.__veri.select_dtypes( #sadece sayısal sütunları seçer
            include=["float64","int64"]
        ).columns

        for sutun in sayisal:

            self.__veri[sutun].fillna( #ortalama ile doldur
                self.__veri[sutun].mean(),
                inplace=True
            )


    def sutun_sil(self, sutun): #belirtilen sütunu veri setinden siler

        self.__veri.drop(
            columns=[sutun],
            inplace=True,
            errors="ignore"
        )


    def dagilim_ciz(self, sutun): #belirtilen sütunun dağılımını görselleştirir

        self.__veri[sutun]\
        .value_counts()\
        .head(10)\
        .plot(kind="bar")

        plt.show()


    def en_cok_yonetmen(self): #en çok film yöneten yönetmenleri gösterir

        print(
            self.__veri["director"]
            .value_counts()
            .head(10)
        )


    def veriyi_kaydet(self, dosya): #temizlenmiş veri setini yeni bir CSV dosyasına kaydeder

        self.__veri.to_csv(
            dosya,
            index=False
        )